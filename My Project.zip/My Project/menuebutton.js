document.addEventListener('DOMContentLoaded', () => {
    // Year and semester link selectors
    const yearLinks = document.querySelectorAll('nav a');
    const yearSections = document.querySelectorAll('.year-section');
    const semesterLinks = document.querySelectorAll('.semester-links a');
    const semesterTopics = document.querySelectorAll('.semester-topics');
    
    // Three-dot button and dropdown
    const threeDotButton = document.querySelector('.three-dot-button');
    const dropdownContent = document.querySelector('.dropdown-content');

    // Hide all year sections
    function hideAllYears() {
        yearSections.forEach(section => {
            section.classList.remove('active');
        });
    }

    // Hide all semester topics
    function hideAllSemesters() {
        semesterTopics.forEach(section => {
            section.classList.remove('active');
        });
    }

    // Add event listeners to year links
    yearLinks.forEach(link => {
        link.addEventListener('click', (e) => {
            e.preventDefault();
            hideAllYears();
            hideAllSemesters(); // Hide all topics when switching years
            const targetYear = document.querySelector(link.getAttribute('href'));
            targetYear.classList.add('active');
        });
    });

    // Add event listeners to semester links
    semesterLinks.forEach(link => {
        link.addEventListener('click', (e) => {
            e.preventDefault();
            hideAllSemesters();
            const targetSem = document.querySelector(link.getAttribute('href'));
            targetSem.classList.add('active');
        });
    });

    // Toggle dropdown menu on three-dot button click
    threeDotButton.addEventListener('click', () => {
        dropdownContent.classList.toggle('show');
    });

    // Close the dropdown if the user clicks outside of it
    window.addEventListener('click', (e) => {
        if (!e.target.matches('.three-dot-button')) {
            if (dropdownContent.classList.contains('show')) {
                dropdownContent.classList.remove('show');
            }
        }
    });
});
