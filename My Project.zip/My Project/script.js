document.addEventListener('DOMContentLoaded', () => {
    // Get year links and year sections
    const year1Link = document.getElementById('link-year1');
    const year2Link = document.getElementById('link-year2');
    const year3Link = document.getElementById('link-year3');
    const year4Link = document.getElementById('link-year4');
    const year1Section = document.getElementById('year1');
    const year2Section = document.getElementById('year2');
    const year3Section = document.getElementById('year3');
    const year4Section = document.getElementById('year4');
    
    // Get semester links and sections for all semesters
    const sem1Link = document.getElementById('link-sem1');
    const sem2Link = document.getElementById('link-sem2');
    const sem3Link = document.getElementById('link-sem3');
    const sem4Link = document.getElementById('link-sem4');
    const sem5Link = document.getElementById('link-sem5');
    const sem6Link = document.getElementById('link-sem6');
    const sem7Link = document.getElementById('link-sem7');
    const sem8Link = document.getElementById('link-sem8');
    
    const sem1Section = document.getElementById('sem1');
    const sem2Section = document.getElementById('sem2');
    const sem3Section = document.getElementById('sem3');
    const sem4Section = document.getElementById('sem4');
    const sem5Section = document.getElementById('sem5');
    const sem6Section = document.getElementById('sem6');
    const sem7Section = document.getElementById('sem7');
    const sem8Section = document.getElementById('sem8');
    
    // Function to hide all year sections
    function hideAllYears() {
        year1Section.classList.remove('active');
        year2Section.classList.remove('active');
        year3Section.classList.remove('active');
        year4Section.classList.remove('active');
    }

    // Function to hide all semester topics
    function hideAllSemesterTopics() {
        sem1Section.classList.remove('active');
        sem2Section.classList.remove('active');
        sem3Section.classList.remove('active');
        sem4Section.classList.remove('active');
        sem5Section.classList.remove('active');
        sem6Section.classList.remove('active');
        sem7Section.classList.remove('active');
        sem8Section.classList.remove('active');
    }

    // Event listener for Year 1
    year1Link.addEventListener('click', () => {
        hideAllYears();
        year1Section.classList.add('active');
        hideAllSemesterTopics(); // Hide any semester topics shown
    });

    // Event listener for Year 2
    year2Link.addEventListener('click', () => {
        hideAllYears();
        year2Section.classList.add('active');
        hideAllSemesterTopics(); // Hide any semester topics shown
    });

    // Event listener for Year 3
    year3Link.addEventListener('click', () => {
        hideAllYears();
        year3Section.classList.add('active');
        hideAllSemesterTopics(); // Hide any semester topics shown
    });

    // Event listener for Year 4
    year4Link.addEventListener('click', () => {
        hideAllYears();
        year4Section.classList.add('active');
        hideAllSemesterTopics(); // Hide any semester topics shown
    });

    // Event listeners for Semesters (only show topics, not hiding semesters)
    sem1Link.addEventListener('click', () => {
        hideAllSemesterTopics();
        sem1Section.classList.add('active');
    });

    sem2Link.addEventListener('click', () => {
        hideAllSemesterTopics();
        sem2Section.classList.add('active');
    });

    sem3Link.addEventListener('click', () => {
        hideAllSemesterTopics();
        sem3Section.classList.add('active');
    });

    sem4Link.addEventListener('click', () => {
        hideAllSemesterTopics();
        sem4Section.classList.add('active');
    });

    sem5Link.addEventListener('click', () => {
        hideAllSemesterTopics();
        sem5Section.classList.add('active');
    });

    sem6Link.addEventListener('click', () => {
        hideAllSemesterTopics();
        sem6Section.classList.add('active');
    });

    sem7Link.addEventListener('click', () => {
        hideAllSemesterTopics();
        sem7Section.classList.add('active');
    });

    sem8Link.addEventListener('click', () => {
        hideAllSemesterTopics();
        sem8Section.classList.add('active');
    });
});
